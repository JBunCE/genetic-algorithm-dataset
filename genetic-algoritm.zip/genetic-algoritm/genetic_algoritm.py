from enum import member
import random
from re import M, S
import statistics
from tkinter import N
import numpy as np
import pandas as pd

from typing import List, TypedDict

class Member(TypedDict):
    chromosome: np.ndarray
    equation_values = List[float]
    wished_value = float
    fitness_err: float

class Solution(TypedDict):
    member: Member

class GeneticAlgorithm():
    def __init__(self) -> None:
        # Parametros
        self.problemdf = pd.read_csv("2024.05.csv", delimiter=';')
        self.solution_list = List[Solution]
        self.less_value_of_y = self.problemdf["y"].min()
    
        self.population: List[Member] = []
        self.initial_population = 5
        self.max_population = 5
        
        self.media_error = 0
        self.percent_of_elitism = 40
        self.breakpoint_line = None
        self.mutation_percent = 60
        self.mutation_percent_gene = 60

    def initization(self):
        # Generar individuos
        for _ in range(0, self.initial_population):
            member = Member()
            member["chromosome"] = np.random.uniform(0, self.less_value_of_y, 5)
            member["fitness_err"] = None
            
            equation_values = self.problemdf.sample(n=1)
            
            member["wished_value"] = equation_values.pop(equation_values.columns[-1]).values[0]
            
            member["equation_values"] = equation_values.values[0]
            
            self.problemdf.drop(equation_values.index, inplace=True)
            self.population.append(member)
        
        self.breakpoint_line = random.randint(1, len(self.population[0]["chromosome"]) - 1)

    def evalutatioon(self):
        for member in self.population:
            if member["fitness_err"] is None:
                a = member["chromosome"][0]
                bcde = member["chromosome"][1:]
                y = a + np.dot(bcde, member["equation_values"]).sum()
                member["fitness_err"] = abs(y - member["wished_value"])
                # print(f"Y: {y} - Wished: {member['wished_value']} - Error: {member['fitness_err']}")
                
                if member["fitness_err"] == 0:
                    self.solution_list.append({"member": member})
                    print(self.solution_list)
                    self.population.remove(member)
                    
                    for m in self.population:
                        if m["wished_value"] == member["wished_value"]:
                            self.population.remove(m)
                
        self.media_error = statistics.mean([member["fitness_err"] for member in self.population])
                
    def crossover(self):
        percent = ((self.percent_of_elitism * len(self.population)) // 100)
        best_members = self.population[:percent]
        rest_population = self.population[percent:]
        
        for selected_member in rest_population:
            for best_member in best_members:
                first_child = Member()
                second_child = Member()
                
                first_child["fitness_err"] = None
                first_child["equation_values"] = best_member["equation_values"]
                first_child["wished_value"] = best_member["wished_value"]
                
                second_child["fitness_err"] = None
                second_child["equation_values"] = selected_member["equation_values"]
                second_child["wished_value"] = selected_member["wished_value"]
                
                first_child["chromosome"] = np.concatenate((selected_member["chromosome"][:self.breakpoint_line], best_member["chromosome"][self.breakpoint_line:]))
                second_child["chromosome"] = np.concatenate((best_member["chromosome"][:self.breakpoint_line], selected_member["chromosome"][self.breakpoint_line:]))
                
                self.population.append(first_child)
                self.population.append(second_child)

    def mutation(self):
        for member in self.population:
            if member["fitness_err"] == None:
                if random.randint(0, 100) <= self.mutation_percent:
                    for i in range(len(member["chromosome"])):
                        if random.randint(0, 100) <= self.mutation_percent_gene:
                            if random.choice([True, False]):
                                member["chromosome"][i] += random.uniform(0, 0.1)
                            else:
                                member["chromosome"][i] -= random.uniform(0, 0.1)
    
    def sort(self):
        self.population = sorted(self.population, key=lambda x: x["fitness_err"])
        
    def run(self):
        self.initization()
        self.evalutatioon()
        self.sort()
        
        while not self.problemdf.empty:
            if len(self.population) <= 5:
                self.initization()
            self.crossover()
            self.mutation()
            self.evalutatioon()
            self.sort()
            # self.pode()

if __name__ == "__main__":
    ga = GeneticAlgorithm()
    ga.run()